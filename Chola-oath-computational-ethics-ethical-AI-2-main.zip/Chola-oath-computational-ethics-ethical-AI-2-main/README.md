# Chola-oath-computational-ethics-ethical-AI
# Choal oath .if a Chola warriors take this oath even god can not save you from Chola warriors  so he  protects the weak women children and old and physically challage and the wound people rest youngstres must form the  protect these people in war and he himself turns into a chola warior and all life forms weak 
# சோழர் சூளுரை சோழர் சபதம்  .சோழ வீரர்கள் இந்த சபதம் எடுத்தால் கடவுளால் கூட உங்களை சோழ வீரர்களிடமிருந்து எதிரிகளை  காப்பாற்ற முடியாது, அதனால் அவர் பலவீனமான பெண் குழந்தைகள் மற்றும் பெரியவர்கள் மற்றும் உடல் ரீதியாக பாதிக்கப்பட்டவர்களையும், காயம்பட்ட மக்கள் இவர்களை  இளைஞர்களையும் எல்லா உயிர் இனங்களும்  போரில் பாதுகாக்க வேண்டும், மேலும் இளைஞர்கள் சோழ வீரனாக மாறுகிறார்கள்  
  # " பொண்ணும் பொருளும் வந்தா போர்க்களம் தான் போவேண்ட ஒருத்தன் நம்பி வந்த உயிர் கொடுக்கும் ஞான சூரண்டா "
  
  # @Scholarly Thugs 
